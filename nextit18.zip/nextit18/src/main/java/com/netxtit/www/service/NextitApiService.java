package com.netxtit.www.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netxtit.www.NextITApiController;

import kr.or.nextit.code.service.ICommCodeService;
import kr.or.nextit.code.vo.CodeVO;

@Service
public class NextitApiService {

//	@Autowired
//	private NextITApiController apiController;
	
	
	public void apiJoin() {
		
		System.out.println("NextitApiService apiJoin");
		
		
	}
	
	
	
}
