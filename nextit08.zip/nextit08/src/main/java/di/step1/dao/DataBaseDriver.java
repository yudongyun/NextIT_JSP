package di.step1.dao;

public interface DataBaseDriver {

	void getConnection();

}
