package di.step2.dao;

public class OracleDriver implements DataBaseDriver{

	public void getConnection() {
		// TODO Auto-generated method stub
		System.out.println("Oracle이 연결되었습니다.");
	}

}
