package kr.or.nextit.free.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import kr.or.nextit.exception.BizNotEffectedException;
import kr.or.nextit.exception.DaoException;
import kr.or.nextit.free.service.FreeBoardServiceImpl;
import kr.or.nextit.free.service.IFreeBoardService;
import kr.or.nextit.free.vo.FreeBoardVO;
import kr.or.nextit.servlet.NextITProcess;

public class freeRegister implements NextITProcess{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("freeRegister process");
		request.setCharacterEncoding("UTF-8");
		
		 // <jsp:useBean id="freeBoard" class="kr.or.nextit.free.vo.FreeBoardVO"></jsp:useBean>
		 // <jsp:setProperty property="*" name="freeBoard"/>
		
		FreeBoardVO freeRegister = new FreeBoardVO();
		BeanUtils.populate(freeRegister, request.getParameterMap());
		
		 System.out.println("freeBoard.toString(): "+ freeRegister.toString());

		 IFreeBoardService freeBoardService = new FreeBoardServiceImpl();
		 try{
		 	freeBoardService.registerBoard(freeRegister);
		 }catch(BizNotEffectedException bne){
		 	bne.printStackTrace();
		 	request.setAttribute("bne", bne);
		 }catch(DaoException de){
		 	de.printStackTrace();
		 	request.setAttribute("de", de);
		 }
		
		return "/WEB-INF/views/free/freeRegister.jsp";
	}

}
