package di.step2.dao;

import org.springframework.stereotype.Repository;

@Repository("tibero1")
public class TiberoDriver implements DataBaseDriver{

	@Override
	public void getConnection() {
		// TODO Auto-generated method stub
		System.out.println("Tibero가 연결 되었습니다.");
	}

}
