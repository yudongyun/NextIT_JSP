package di.step3.dao;

public interface DataBaseDriver {

	void getConnection();

}
