package kr.or.nextit.free.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import kr.or.nextit.exception.BizNotEffectedException;
import kr.or.nextit.exception.DaoException;
import kr.or.nextit.free.service.FreeBoardServiceImpl;
import kr.or.nextit.free.service.IFreeBoardService;
import kr.or.nextit.free.vo.FreeBoardSearchVO;
import kr.or.nextit.free.vo.FreeBoardVO;
import kr.or.nextit.servlet.NextITProcess;

public class freeView implements NextITProcess{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("freeView process");
		
		// <jsp:useBean id="searchVO" class="kr.or.nextit.free.vo.FreeBoardSearchVO"></jsp:useBean>
		// <jsp:setProperty property="*" name="searchVO"/>
		
		FreeBoardVO freeview = new FreeBoardVO();
		BeanUtils.populate(freeview, request.getParameterMap());
		
		FreeBoardSearchVO searchfreeview = new FreeBoardSearchVO();
		BeanUtils.populate(searchfreeview, request.getParameterMap());

			System.out.println(searchfreeview.toString());
			
			String boNo = request.getParameter("boNo");
			System.out.println("boNo : " + boNo);
			
			IFreeBoardService freeBoardService = new FreeBoardServiceImpl();
			
			try{
				FreeBoardVO freeBoard = freeBoardService.getBoard(boNo);
			
				freeBoardService.increaseHit(boNo);
				
				System.out.println("freeBoard: "+ freeBoard.toString());
				request.setAttribute("freeBoard", freeBoard);
			}catch(BizNotEffectedException bne){
				request.setAttribute("bne", bne);
				bne.printStackTrace();
			}catch(DaoException de){
				request.setAttribute("de", de);
				de.printStackTrace();
			}


		
		return "/WEB-INF/views/free/freeView.jsp";
	}

}
