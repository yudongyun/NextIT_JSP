package di.step2.dao;

public class MysqlDriver implements DataBaseDriver{

	public void getConnection() {
		// TODO Auto-generated method stub
		System.out.println("Mysql이 연결 되었습니다.");
	}

}
