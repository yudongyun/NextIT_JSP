package kr.or.nextit.common.valid;

public interface FreeFrom {

}
