package kr.or.nextit.free.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import kr.or.nextit.code.service.CommCodeServiceImpl;
import kr.or.nextit.code.service.ICommCodeService;
import kr.or.nextit.code.vo.CodeVO;
import kr.or.nextit.exception.BizNotEffectedException;
import kr.or.nextit.exception.DaoException;
import kr.or.nextit.free.service.FreeBoardServiceImpl;
import kr.or.nextit.free.service.IFreeBoardService;
import kr.or.nextit.free.vo.FreeBoardSearchVO;
import kr.or.nextit.free.vo.FreeBoardVO;
import kr.or.nextit.member.vo.MemberVO;
import kr.or.nextit.servlet.NextITProcess;

public class freeList implements NextITProcess{

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("UTF-8");
		
		System.out.println("freeList process");
		
		// <jsp:useBean id="searchVO" class="kr.or.nextit.free.vo.FreeBoardSearchVO"></jsp:useBean>
		// <jsp:setProperty property="*" name="searchVO"/>

		FreeBoardVO free = new FreeBoardVO();
		BeanUtils.populate(free, request.getParameterMap());
		
		FreeBoardSearchVO searchfree = new FreeBoardSearchVO();
		BeanUtils.populate(searchfree, request.getParameterMap());


		ICommCodeService codeService = new CommCodeServiceImpl();
		List<CodeVO> categoryList = codeService.getCodeListByParent("BC00");
		request.setAttribute("categoryList", categoryList);



		IFreeBoardService freeBoardService = new FreeBoardServiceImpl();
		try{
			//List<FreeBoardVO> freeBoardList = freeBoardService.getBoardList(pagingVO);
			List<FreeBoardVO> freeBoardList = freeBoardService.getBoardList(searchfree);
			request.setAttribute("freeBoardList", freeBoardList);
		}catch(BizNotEffectedException bne){
			bne.printStackTrace();
			request.setAttribute("bne", bne);
		}catch(DaoException de){
			de.printStackTrace();
			request.setAttribute("de", de);
		}
		
		return "WEB-INF/views/free/freeList.jsp";
	}

}
