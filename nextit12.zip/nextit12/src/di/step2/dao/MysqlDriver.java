package di.step2.dao;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

// @Component("mysql")
@Repository("mysql")
public class MysqlDriver implements DataBaseDriver{

	public void getConnection() {
		// TODO Auto-generated method stub
		System.out.println("Mysql이 연결 되었습니다.");
	}

}
