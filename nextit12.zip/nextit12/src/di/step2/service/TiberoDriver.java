package di.step2.service;

import org.springframework.stereotype.Repository;

@Repository("tibero2")
public class TiberoDriver {

}
