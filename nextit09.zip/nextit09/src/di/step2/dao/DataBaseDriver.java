package di.step2.dao;

public interface DataBaseDriver {

	void getConnection();

}
