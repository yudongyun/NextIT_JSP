package di.step2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import di.step2.dao.DataBaseDriver;
import di.step2.dao.OracleDriver;
import di.step2.service.FreeBoardService;
import di.step2.service.MemberService;

public class NextITProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// DataBaseDriver driver = new OracleDriver();
		// DataBaseDriver driver = new MysqlDriver();
		
		ApplicationContext context = new GenericXmlApplicationContext("spring/step2.xml"); // 지시서 등록
		
		
		
		
		// 글쓰기 로직
		// FreeBoardService free = new FreeBoardService(driver);
				
		FreeBoardService free = context.getBean(FreeBoardService.class); // 타입으로 바로 지정 ( 이름을 안정했으니 )
		free.insertBoard();
		
		MemberService member = context.getBean(MemberService.class);
		member.insertMember();
		
	}

}
