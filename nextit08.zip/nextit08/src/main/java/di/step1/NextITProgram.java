package di.step1;

import di.step1.service.FreeBoardService;

public class NextITProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 디비연결 로직
		
		// 글쓰기 로직
		FreeBoardService free = new FreeBoardService();
		free.insertBoard();
		
	}

}
