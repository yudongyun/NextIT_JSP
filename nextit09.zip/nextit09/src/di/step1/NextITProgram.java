package di.step1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import di.step1.dao.DataBaseDriver;
import di.step1.dao.OracleDriver;
import di.step1.service.FreeBoardService;

public class NextITProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// DataBaseDriver driver = new OracleDriver();
		// DataBaseDriver driver = new MysqlDriver();
		
		// step1 의 지시서에 작성해두면 가져다와서 사용할 수 있다 ( bean으로 생성 )
		// new 를 통해서 더이상 객체를 만들지 않는다.
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring/step1.xml");
		
		DataBaseDriver driver = (DataBaseDriver) context.getBean("driver");
		
		// 글쓰기 로직
		FreeBoardService free = new FreeBoardService(driver);
		free.insertBoard();
		
	}

}
