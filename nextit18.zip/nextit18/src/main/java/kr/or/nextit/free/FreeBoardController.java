package kr.or.nextit.free;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import kr.or.nextit.code.service.CommCodeServiceImpl;
import kr.or.nextit.code.service.ICommCodeService;
import kr.or.nextit.code.vo.CodeVO;
import kr.or.nextit.exception.BizNotEffectedException;
import kr.or.nextit.exception.BizNotFoundException;
import kr.or.nextit.exception.BizPasswordNotMatchedException;
import kr.or.nextit.free.service.FreeBoardServiceImpl;
import kr.or.nextit.free.service.IFreeBoardService;
import kr.or.nextit.free.vo.FreeBoardSearchVO;
import kr.or.nextit.free.vo.FreeBoardVO;
import kr.or.nextit.member.vo.MemberVO;

@Controller
@RequestMapping("/free")
public class FreeBoardController {

	@Resource(name="codeService")
	private ICommCodeService codeService;
	@Resource(name="freeBoardService")
	private IFreeBoardService freeBoardService;
	
	
	@RequestMapping("/freeList")
	public String freeList(HttpServletRequest request,@ModelAttribute FreeBoardSearchVO searchVO,Model model) {
		System.out.println("freeBoardController freeList");
		
		MemberVO memberVO = (MemberVO) request.getSession().getAttribute("memberVO");
		if(memberVO == null){
			return "redirect:/login/login.do?msg=none";
		}
		
		List<CodeVO> categoryList  = codeService.getCodeListByParent("BC00");
		model.addAttribute("categoryList", categoryList);
		
		try{
			List<FreeBoardVO> freeBoardList = freeBoardService.getBoardList(searchVO);
			model.addAttribute("freeBoardList", freeBoardList);
			model.addAttribute("searchVO", searchVO);
		}catch(BizNotEffectedException bne){
			model.addAttribute("bne", bne);
			bne.printStackTrace();
		}catch(Exception de){
			model.addAttribute("de", de);
			de.printStackTrace();
		}

		return "/free/freeList";
	}
	
	@RequestMapping("/freeForm")
	public String freeForm(HttpServletRequest request,Model model) {
		
		MemberVO memberVO = (MemberVO) request.getSession().getAttribute("memberVO");
		System.out.println("freeBoardController freeForm MemberVO : " + memberVO.toString());
		if(memberVO == null){
			return "redirect:/login/login.do?msg=none";
		}
		
		List<CodeVO> categoryList = codeService.getCodeListByParent("BC00");

		model.addAttribute("categoryList", categoryList);
		
		return "/free/freeForm";
	}
	
	@RequestMapping(value="/freeRegister" , method= RequestMethod.POST)
	public String freeRegister(HttpServletRequest request,@ModelAttribute FreeBoardVO freeBoard,Model model) {
		System.out.println("freeBoardController freeRegister");
		
		MemberVO memberVO = (MemberVO) request.getSession().getAttribute("memberVO");
		if(memberVO == null){
			return "redirect:/login/login.do?msg=none";
		}
		System.out.println("free .toString() : " + freeBoard);
		
		try{
			if(freeBoard.getBoTitle() != null && ! freeBoard.getBoTitle().equals("")) {
				freeBoardService.registerBoard(freeBoard);
			}else {
				throw new Exception();
			}
			return "redirect:/free/freeList";
		}catch(BizNotEffectedException bne){
			model.addAttribute("bne", bne);
			bne.printStackTrace();
		}catch(Exception de){
			model.addAttribute("de", de);
			de.printStackTrace();
		}
		
		
		return "/free/freeRegister";
	}
	
	@RequestMapping("/freeView")
	public String freeView(HttpServletRequest request,@ModelAttribute FreeBoardSearchVO searchVO,@RequestParam String boNo,Model model) {
		System.out.println("freeBoardController freeView");
		
		MemberVO memberVO = (MemberVO) request.getSession().getAttribute("memberVO");
		if(memberVO == null){
			return "redirect:/login/login.do?msg=none";
		}
		
//		System.out.println("searchType: "+searchVO.getSearchType() + " , searchWord: "+searchVO.getSearchWord()+ " , searchCategory: "+searchVO.getSearchCategory()+ " , curPage: "+searchVO.getCurPage()+ " , rowSizePerPage: "+searchVO.getRowSizePerPage());
//		String boNo = request.getParameter("boNo");
//		System.out.println("boNo : " + boNo);
		
		try{
			FreeBoardVO freeBoard = freeBoardService.getBoard(boNo);
			freeBoardService.increaseHit(boNo);
			
			model.addAttribute("freeBoard", freeBoard);
			model.addAttribute("searchVO", searchVO);
			
		}catch(BizNotEffectedException bne){
			model.addAttribute("bne", bne);
			bne.printStackTrace();
		}catch(Exception de){
			model.addAttribute("de", de);
			de.printStackTrace();
		}
		
		
		return "/free/freeView";
	}
	
	@RequestMapping("/freeEdit")
	public String freeEdit(HttpServletRequest request,Model model,@RequestParam String boNo) {
		System.out.println("FreeBoardController freeEdit boNo : "+ boNo);
		
		MemberVO memberVO = (MemberVO) request.getSession().getAttribute("memberVO");
		if(memberVO == null){
			return "redirect:/login/login.do?msg=none";
		}
		
		List<CodeVO> categoryList = codeService.getCodeListByParent("BC00");
		
		model.addAttribute("categoryList", categoryList);
		
		try{
			FreeBoardVO freeBoard = freeBoardService.getBoard(boNo);
			model.addAttribute("freeBoard", freeBoard);
		}catch(BizNotEffectedException bne){
			model.addAttribute("bne", bne);
			bne.printStackTrace();
		}catch(Exception de){
			model.addAttribute("de", de);
			de.printStackTrace();
		}
		
		return "/free/freeEdit";
	}
	
	
	@RequestMapping("/freeModify")
	public String freeModify(HttpServletRequest request,@ModelAttribute FreeBoardVO freeBoard,Model model) {
		System.out.println("FreeBoardController freeModify");
		
		MemberVO memberVO = (MemberVO) request.getSession().getAttribute("memberVO");
		if(memberVO == null){
			return "redirect:/login/login.do?msg=none";
		}
		
		
		try{
			if(freeBoard !=null && ! freeBoard.getBoTitle().equals("")) {
				freeBoardService.modifyBoard(freeBoard);
				model.addAttribute("freeBoard", freeBoard);
				return "redirect:/free/freeView";
			}else {
				throw new Exception();
			}
		}catch(BizNotFoundException bnf){
			model.addAttribute("bnf", bnf);
			bnf.printStackTrace();
		}catch(BizPasswordNotMatchedException bpn){
			model.addAttribute("bpn", bpn);
			bpn.printStackTrace();
		}catch(BizNotEffectedException bne){
			model.addAttribute("bne", bne);
			bne.printStackTrace();
		}catch(Exception de){
			model.addAttribute("de", de);
			de.printStackTrace();
		}
		
		return "/free/freeModify";
	}
	
	@RequestMapping("/freeDelete")
	public String freeDelete(HttpServletRequest request,@ModelAttribute FreeBoardVO freeBoard,Model model) {
		System.out.println("FreeBoardController freeDelete");
		
		MemberVO memberVO = (MemberVO) request.getSession().getAttribute("memberVO");
		if(memberVO == null){
			return "redirect:/login/login.do?msg=none";
		}
		System.out.println(freeBoard);
		try{
			if(freeBoard != null && !freeBoard.getBoNo().equals("")) {
				freeBoardService.deleteBoard(freeBoard);
				return "redirect:/free/freeList";
			}
		}catch(BizNotEffectedException | BizNotFoundException bne){
			model.addAttribute("bne", bne);
			bne.printStackTrace();
		}catch(BizPasswordNotMatchedException bpn){
			model.addAttribute("bpn", bpn);
			bpn.printStackTrace();
		}catch(Exception de){
			model.addAttribute("de", de);
			de.printStackTrace();
		}
		
		
		return "/free/freeDelete";
	}
	
	
	@RequestMapping("/freeHide")
	public String freeHide(HttpServletRequest request,Model model,@RequestParam String memId,@RequestParam String boNo) {
		System.out.println("FreeBoardController freeHide");
		
		MemberVO memberVO = (MemberVO) request.getSession().getAttribute("memberVO");
		if(memberVO == null){
			return "redirect:/login/login.do?msg=none";
		}
		try{
			if(memId != null && boNo != null) {
				freeBoardService.hideBoard(memId, boNo);
			}else {
				throw new Exception();
			}
			return "redirect:/free/freeList";
		}catch(BizNotEffectedException bne){
			model.addAttribute("bne", bne);
			bne.printStackTrace();
		}catch(Exception de){
			model.addAttribute("de", de);
			de.printStackTrace();
		}
		
		
		return "/free/freeHide";
	}
	
}
